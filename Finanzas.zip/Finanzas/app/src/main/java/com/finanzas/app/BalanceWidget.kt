package com.finanzas.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class BalanceWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
    }

    companion object {
        private const val GREEN = 0xFF4ADE80.toInt()
        private const val RED = 0xFFF87171.toInt()

        fun refresh(context: Context) {
            val m = AppWidgetManager.getInstance(context)
            val ids = m.getAppWidgetIds(ComponentName(context, BalanceWidget::class.java))
            ids.forEach { render(context, m, it) }
        }

        private fun render(c: Context, m: AppWidgetManager, id: Int) {
            val s = summarize(Store.load(c))
            val v = RemoteViews(c.packageName, R.layout.widget_balance)

            v.setTextViewText(R.id.day_net, Fmt.money(s.day.net))
            v.setTextColor(R.id.day_net, if (s.day.net < 0) RED else GREEN)
            v.setTextViewText(R.id.day_detail, "▲ ${Fmt.money(s.day.inc)}   ▼ ${Fmt.money(s.day.exp)}")

            v.setTextViewText(R.id.week_net, Fmt.money(s.week.net))
            v.setTextColor(R.id.week_net, if (s.week.net < 0) RED else GREEN)
            v.setTextViewText(R.id.week_detail, "▲ ${Fmt.money(s.week.inc)}   ▼ ${Fmt.money(s.week.exp)}")
            v.setTextViewText(
                R.id.week_src,
                "Uber ${Fmt.money(s.week.uber)}\nDidi ${Fmt.money(s.week.didi)}\nGasolina ${Fmt.money(s.week.gas)}"
            )

            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.root, pi)
            m.updateAppWidget(id, v)
        }
    }
}
