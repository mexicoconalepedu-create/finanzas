package com.finanzas.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.Locale

data class Tx(val id: Long, val amount: Double, val isIncome: Boolean, val note: String, val ts: Long)

data class Sum(val inc: Double, val exp: Double) { val net get() = inc - exp }
data class Summary(val day: Sum, val week: Sum)

object Store {
    private const val PREFS = "finanzas"
    private const val KEY = "txs"

    fun load(c: Context): List<Tx> {
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Tx(o.getLong("id"), o.getDouble("amount"), o.getBoolean("inc"), o.getString("note"), o.getLong("ts"))
        }
    }

    fun save(c: Context, list: List<Tx>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("amount", it.amount)
                .put("inc", it.isIncome).put("note", it.note).put("ts", it.ts))
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}

object Fmt {
    private val mx = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
    fun money(d: Double): String = mx.format(d)
}

fun summarize(list: List<Tx>): Summary {
    val z = ZoneId.systemDefault()
    val today = LocalDate.now(z)
    val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    fun since(from: LocalDate): Sum {
        val l = list.filter { !Instant.ofEpochMilli(it.ts).atZone(z).toLocalDate().isBefore(from) }
        return Sum(l.filter { it.isIncome }.sumOf { it.amount }, l.filter { !it.isIncome }.sumOf { it.amount })
    }
    return Summary(since(today), since(monday))
}
