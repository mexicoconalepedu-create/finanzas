package com.finanzas.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.Locale

/** src: "uber", "didi", "gasolina" o vacio (ingreso/egreso generico). */
data class Tx(
    val id: Long,
    val amount: Double,
    val isIncome: Boolean,
    val note: String,
    val ts: Long,
    val src: String = ""
)

data class Sum(
    val uber: Double,
    val didi: Double,
    val otherInc: Double,
    val gas: Double,
    val otherExp: Double
) {
    val inc get() = uber + didi + otherInc
    val exp get() = gas + otherExp
    val net get() = inc - exp
}

data class Summary(val day: Sum, val week: Sum)

object Store {
    private const val PREFS = "finanzas"
    private const val KEY = "txs"

    fun load(c: Context): List<Tx> {
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Tx(
                o.getLong("id"), o.getDouble("amount"), o.getBoolean("inc"),
                o.getString("note"), o.getLong("ts"), o.optString("src", "")
            )
        }
    }

    fun save(c: Context, list: List<Tx>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("amount", it.amount)
                    .put("inc", it.isIncome).put("note", it.note)
                    .put("ts", it.ts).put("src", it.src)
            )
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}

object Fmt {
    private val mx = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
    fun money(d: Double): String = mx.format(d)
}

/** El dia empieza a las 6:00 a. m. */
fun dayStart(ms: Long): Long {
    val z = ZoneId.systemDefault()
    val date = Instant.ofEpochMilli(ms).atZone(z).minusHours(6).toLocalDate()
    return date.atTime(6, 0).atZone(z).toInstant().toEpochMilli()
}

/** La semana empieza el lunes a las 6:00 a. m. */
fun weekStart(ms: Long): Long {
    val z = ZoneId.systemDefault()
    val date = Instant.ofEpochMilli(ms).atZone(z).minusHours(6).toLocalDate()
        .with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    return date.atTime(6, 0).atZone(z).toInstant().toEpochMilli()
}

fun sumOf(list: List<Tx>): Sum {
    var u = 0.0; var d = 0.0; var oi = 0.0; var g = 0.0; var oe = 0.0
    for (t in list) {
        if (t.isIncome) {
            when (t.src) {
                "uber" -> u += t.amount
                "didi" -> d += t.amount
                else -> oi += t.amount
            }
        } else {
            if (t.src == "gasolina") g += t.amount else oe += t.amount
        }
    }
    return Sum(u, d, oi, g, oe)
}

fun summarize(list: List<Tx>, now: Long = System.currentTimeMillis()): Summary {
    val ds = dayStart(now)
    val ws = weekStart(now)
    return Summary(sumOf(list.filter { it.ts >= ds }), sumOf(list.filter { it.ts >= ws }))
}
