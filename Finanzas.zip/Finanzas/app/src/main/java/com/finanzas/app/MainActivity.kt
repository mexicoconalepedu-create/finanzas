package com.finanzas.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val Green = Color(0xFF16A34A)
private val Red = Color(0xFFDC2626)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var txs by remember { mutableStateOf(Store.load(ctx)) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val sum = remember(txs) { summarize(txs) }

    fun commit(list: List<Tx>) {
        Store.save(ctx, list)
        txs = list
        BalanceWidget.refresh(ctx)
    }

    fun add(income: Boolean) {
        val v = amount.replace(",", ".").toDoubleOrNull() ?: return
        if (v <= 0) return
        val now = System.currentTimeMillis()
        commit(listOf(Tx(now, v, income, note.trim(), now)) + txs)
        amount = ""; note = ""
    }

    val fmt = remember { DateTimeFormatter.ofPattern("dd/MM HH:mm") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().statusBarsPadding().imePadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Mis Finanzas", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { SummaryCard("Hoy", sum.day) }
        item { SummaryCard("Esta semana", sum.week) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Monto (MXN)") }, singleLine = true,
                    prefix = { Text("$") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Concepto (opcional)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { add(true) }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("+ Ingreso") }
                    Button(onClick = { add(false) }, modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("− Egreso") }
                }
            }
        }
        item { Text("Movimientos", fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        items(txs, key = { it.id }) { t ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (t.note.isEmpty()) (if (t.isIncome) "Ingreso" else "Egreso") else t.note)
                    Text(
                        Instant.ofEpochMilli(t.ts).atZone(ZoneId.systemDefault()).format(fmt),
                        fontSize = 12.sp, color = Color.Gray
                    )
                }
                Text(
                    (if (t.isIncome) "+" else "−") + Fmt.money(t.amount),
                    color = if (t.isIncome) Green else Red, fontWeight = FontWeight.SemiBold
                )
                TextButton(onClick = { commit(txs.filter { it.id != t.id }) }) { Text("✕") }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, s: Sum) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.Gray, fontSize = 13.sp)
            Text(
                Fmt.money(s.net), fontSize = 28.sp, fontWeight = FontWeight.Bold,
                color = if (s.net < 0) Red else Green
            )
            Text("▲ ${Fmt.money(s.inc)}    ▼ ${Fmt.money(s.exp)}", fontSize = 13.sp)
        }
    }
}
