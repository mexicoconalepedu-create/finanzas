package com.finanzas.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val cUber = Color(0xFF0097A7)
private val cDidi = Color(0xFFEF6C00)
private val cGas = Color(0xFFD32F2F)
private val cOtros = Color(0xFF7B1FA2)
private val cInc = Color(0xFF2E7D32)
private val cNet = Color(0xFF1565C0)
private val cPos = Color(0xFF2E7D32)
private val cNeg = Color(0xFFD32F2F)

private val es = Locale("es", "MX")
private val fullFmt = DateTimeFormatter.ofPattern("EEE d MMM yyyy, HH:mm", es)
private val dayFmt = DateTimeFormatter.ofPattern("d MMM", es)

class Pal(val bg: Color, val card: Color, val muted: Color)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                val pal = if (dark) Pal(Color(0xFF0F1114), Color(0xFF1B1E23), Color(0xFF9AA3AE))
                else Pal(Color(0xFFEEF0F3), Color.White, Color(0xFF6B7480))
                App(pal)
            }
        }
    }
}

@Composable
fun App(pal: Pal) {
    val ctx = LocalContext.current
    var txs by remember { mutableStateOf(Store.load(ctx)) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var daysAgo by remember { mutableStateOf(0) }
    var week by remember { mutableStateOf(true) }

    val now = System.currentTimeMillis()
    val ws = weekStart(now)
    val from = if (week) ws else dayStart(now)
    val p = sumOf(txs.filter { it.ts >= from })
    val cur = txs.filter { it.ts >= ws }.sortedByDescending { it.ts }
    val past = txs.filter { it.ts < ws }.groupBy { weekStart(it.ts) }
        .toList().sortedByDescending { it.first }

    fun commit(list: List<Tx>) {
        Store.save(ctx, list)
        txs = list
        BalanceWidget.refresh(ctx)
    }

    fun add(src: String, income: Boolean) {
        val v = amount.replace(",", ".").toDoubleOrNull() ?: return
        if (v <= 0) return
        val t = System.currentTimeMillis()
        val ts = if (daysAgo == 0) t else
            LocalDate.now().minusDays(daysAgo.toLong()).atTime(12, 0)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        commit(txs + Tx(t, Math.round(v * 100) / 100.0, income, note.trim(), ts, src))
        amount = ""; note = ""; daysAgo = 0
    }

    fun delete(t: Tx) = commit(txs.filter { it.id != t.id })

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(pal.bg),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text("Mis Finanzas", fontSize = 22.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (week) "Semana desde el " + Instant.ofEpochMilli(ws).atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("EEE d MMM", es)) + ", 6:00 a. m. Reinicia cada lunes."
                    else "Desde las 6:00 a. m. de hoy.",
                    fontSize = 13.sp, color = pal.muted
                )
            }
        }

        // Cuadros de colores
        item {
            Box2(pal) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Uber", p.uber, cUber, Modifier.weight(1f))
                    Tile("Didi", p.didi, cDidi, Modifier.weight(1f))
                    Tile("Gasolina", p.gas, cGas, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tile("Otros egresos", p.otherExp, cOtros, Modifier.weight(1f))
                    Tile("Ingresos", p.inc, cInc, Modifier.weight(1f))
                    Tile("Sobró", p.net, cNet, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Esta semana", pal, on = week) { week = true }
                    Pill("Hoy", pal, on = !week) { week = false }
                }
            }
        }

        // Registrar
        item {
            Box2(pal) {
                Text("Registrar", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    label = { Text("Monto (MXN)") }, singleLine = true,
                    prefix = { Text("$") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = note, onValueChange = { note = it },
                    label = { Text("Concepto (opcional)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Text("Fecha del movimiento", fontSize = 13.sp, color = pal.muted)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Hoy", pal, on = daysAgo == 0) { daysAgo = 0 }
                    Pill("Ayer", pal, on = daysAgo == 1) { daysAgo = 1 }
                    Pill("Hace 2 días", pal, on = daysAgo == 2) { daysAgo = 2 }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("+ Uber", pal, dot = cUber, modifier = Modifier.weight(1f)) { add("uber", true) }
                    Pill("+ Didi", pal, dot = cDidi, modifier = Modifier.weight(1f)) { add("didi", true) }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("− Gasolina", pal, dot = cGas, modifier = Modifier.weight(1f)) { add("gasolina", false) }
                    Pill("− Otro egreso", pal, dot = cOtros, modifier = Modifier.weight(1f)) { add("", false) }
                }
            }
        }

        // Estructura (gráfica circular)
        item {
            val segs = listOf(
                Triple("Didi", p.didi, cDidi),
                Triple("Uber", p.uber, cUber),
                Triple("Gasolina", p.gas, cGas),
                Triple("Otros gastos", p.otherExp, cOtros)
            )
            val total = segs.sumOf { it.second }
            Box2(pal) {
                Text(
                    if (week) "Estructura de la semana" else "Estructura de hoy",
                    fontSize = 17.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val track = pal.muted.copy(alpha = 0.25f)
                    Canvas(Modifier.size(210.dp)) {
                        val stroke = 34.dp.toPx()
                        val d = size.minDimension - stroke
                        val tl = Offset(stroke / 2, stroke / 2)
                        val sz = Size(d, d)
                        drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(stroke))
                        if (total > 0) {
                            var a = -90f
                            for (s in segs) {
                                if (s.second > 0) {
                                    val sw = (s.second / total * 360.0).toFloat()
                                    drawArc(s.third, a, sw, false, tl, sz, style = Stroke(stroke))
                                    a += sw
                                }
                            }
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (total > 0) {
                            Text("Total movido", fontSize = 12.sp, color = pal.muted)
                            Text(Fmt.money(total), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Text("Sin movimientos", fontSize = 13.sp, color = pal.muted, textAlign = TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                segs.forEach { s ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(s.third))
                        Spacer(Modifier.width(10.dp))
                        Text(s.first, Modifier.weight(1f))
                        Text(Fmt.money(s.second), fontWeight = FontWeight.Bold)
                        val pct = if (total > 0) Math.round(s.second * 100 / total).toInt() else 0
                        Text("$pct %", Modifier.width(48.dp), fontSize = 12.sp, color = pal.muted, textAlign = TextAlign.End)
                    }
                }
            }
        }

        // Movimientos de la semana
        item {
            Box2(pal) {
                Text("Movimientos de esta semana", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                if (cur.isEmpty()) {
                    Text("Sin movimientos esta semana.", color = pal.muted)
                } else {
                    cur.forEach { MovRow(it, pal) { t -> delete(t) } }
                }
            }
        }

        // Historial de semanas
        item {
            Box2(pal) {
                Text("Historial de semanas", fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(6.dp))
                if (past.isEmpty()) {
                    Text("Las semanas terminadas aparecerán aquí cada lunes a las 6:00 a. m.", color = pal.muted)
                } else {
                    past.forEach { (start, list) -> WeekItem(start, list, pal) { t -> delete(t) } }
                }
            }
        }
    }
}

@Composable
fun Box2(pal: Pal, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(pal.card).padding(14.dp),
        content = content
    )
}

@Composable
fun Tile(label: String, value: Double, color: Color, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).background(color)
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        Text(label, color = Color.White, fontSize = 12.sp, maxLines = 1)
        Text(Fmt.money(value), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun Pill(
    text: String, pal: Pal, dot: Color? = null, on: Boolean = false,
    modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val bg = if (on) MaterialTheme.colorScheme.onSurface else pal.muted.copy(alpha = 0.15f)
    val fg = if (on) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurface
    Row(
        modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dot != null) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = fg, fontWeight = FontWeight.Medium, fontSize = 15.sp)
    }
}

private fun labelOf(t: Tx): String {
    val base = if (t.isIncome) {
        when (t.src) { "uber" -> "Uber"; "didi" -> "Didi"; else -> "Ingreso" }
    } else {
        if (t.src == "gasolina") "Gasolina" else "Egreso"
    }
    return if (t.note.isEmpty()) base else "$base: ${t.note}"
}

@Composable
fun MovRow(t: Tx, pal: Pal, onDelete: (Tx) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(labelOf(t), maxLines = 1)
            Text(
                Instant.ofEpochMilli(t.ts).atZone(ZoneId.systemDefault()).format(fullFmt),
                fontSize = 12.sp, color = pal.muted
            )
        }
        Text(
            (if (t.isIncome) "+" else "−") + Fmt.money(t.amount),
            color = if (t.isIncome) cPos else cNeg, fontWeight = FontWeight.Bold
        )
        TextButton(onClick = { onDelete(t) }) { Text("✕", color = pal.muted) }
    }
}

@Composable
fun WeekItem(start: Long, list: List<Tx>, pal: Pal, onDelete: (Tx) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val s = sumOf(list)
    val z = ZoneId.systemDefault()
    val a = Instant.ofEpochMilli(start).atZone(z)
    val range = a.format(dayFmt) + " al " + a.plusDays(6).format(dayFmt)
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(Modifier.weight(1f)) {
                Text(range)
                Text(
                    "Uber ${Fmt.money(s.uber)}  Didi ${Fmt.money(s.didi)}\n" +
                        "Egresos ${Fmt.money(s.exp)} (Gasolina ${Fmt.money(s.gas)})",
                    fontSize = 12.sp, color = pal.muted
                )
            }
            Text(
                Fmt.money(s.net), fontWeight = FontWeight.Bold, fontSize = 17.sp,
                color = if (s.net < 0) cNeg else cPos
            )
        }
        if (open) {
            list.sortedByDescending { it.ts }.forEach { MovRow(it, pal, onDelete) }
        }
    }
}
